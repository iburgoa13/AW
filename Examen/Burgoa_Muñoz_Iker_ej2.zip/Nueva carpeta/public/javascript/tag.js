$(function () {
    let tags = "";
    let t = []
    // Add tag
    $('.t').on('click',  function () {
     
      
         t = $('#nTags').prop('value').split("@");
         tags = $('#nTags').prop('value');
        console.log(t);
        console.log(tags);
        let valor = $(this).text();
        if(!t.includes(valor)){
            tags=tags+"@"+valor;
            $('#nTags').val(tags);
        }
      
        
       
       
    });
	
})